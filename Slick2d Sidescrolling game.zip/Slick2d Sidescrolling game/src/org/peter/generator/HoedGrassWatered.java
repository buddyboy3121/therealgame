package org.peter.generator;

public class HoedGrassWatered extends Tile {

	public HoedGrassWatered(int x, int y) {
		super(x, y, 4, "images/hoed-watered.png");
	}
}
