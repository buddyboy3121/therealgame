package MainGame;

import org.newdawn.slick.*;
import org.newdawn.slick.state.*;

public class MainMenu extends BasicGameState {

	public void init(GameContainer container, StateBasedGame sbg) throws SlickException {
		
	}
	
	public void render(GameContainer container, StateBasedGame sbg, Graphics g) throws SlickException { 
		
	}
	
	public void update(GameContainer container, StateBasedGame sbg, int delta) throws SlickException {
		
	}

	public int getID() {
		return 0;
	}
}
