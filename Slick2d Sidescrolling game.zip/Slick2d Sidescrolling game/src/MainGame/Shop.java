package MainGame;

import org.newdawn.slick.state.*;
import org.newdawn.slick.*;

public class Shop extends BasicGameState {
	
	public void init(GameContainer container, StateBasedGame sbg) throws SlickException {
		
	}
	
	public void update(GameContainer container, StateBasedGame sbg, int delta) throws SlickException {
		
	}
	
	public void render(GameContainer container, StateBasedGame sbg, Graphics g) throws SlickException {
		
	}
	
	public int getID() {
		return 2;
	}

}
