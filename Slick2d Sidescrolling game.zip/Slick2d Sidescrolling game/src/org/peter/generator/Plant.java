package org.peter.generator;

public class Plant extends UnusualEffects {

	public Plant(int x, int y) {
		super(x, y, 1, "images/plant.png");
	}
}
