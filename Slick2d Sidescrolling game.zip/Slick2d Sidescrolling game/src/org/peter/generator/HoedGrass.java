package org.peter.generator;

public class HoedGrass extends Tile {

	public HoedGrass(int x, int y) {
		super(x, y, 3, "images/hoed.png");
	}
}
