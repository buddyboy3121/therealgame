package org.peter.generator;

public class Grass extends Tile {

	public Grass(float x, float y) {
		super(x, y, 0, "images/grass.png");
	}

}
