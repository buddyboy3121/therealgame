package MainGame;

public class Pumpkin extends Crops {

	public Pumpkin() {
		super("images/pumpkin.png");
		
	}

	@Override
	public void use() {
		
		
	}

}
